<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;

    protected $guarded = [];
    
    public function academicLevel(){
        return $this->belongsTo(AcademicLevel::class,'academic_level_id');
    }

     public function stageLevel(){
        return $this->belongsTo(StageLevel::class,'stage_level_id');
    }

    public function department(){
        return $this->belongsTo(Department::class,'department_id');
    }

    public function teacher(){
        return $this->belongsTo(Admin::class,'admin_id');
    }

    public function scopeActive($query){
        return $query->where('status' ,'active');
    }
}
