<?php

namespace App\Http\Controllers\dashboard;

use App\Models\Admin;
use App\Models\Course;
use App\Models\Department;
use App\Models\StageLevel;
use Illuminate\Http\Request;
use App\Models\AcademicLevel;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class CourseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function cardAllCourses(Request $request)
    {
        if (Auth::guard('admin')->user()->can('access any')) {
            $courses = Course::with(['academicLevel', 'stageLevel', 'department', 'teacher'])->get(); 
            $courses = $courses->map(function ($course) {
                $course->academicLevel_name = optional($course->academicLevel)->name ?? 'No Academic Level';
                $course->stageLevel_name = optional($course->stageLevel)->name ?? 'No Stage Level';
                $course->department_name = optional($course->department)->name ?? 'No Department';
                $course->department_name = optional($course->department)->name ?? 'No Department';
                return $course; 
            });
            $academicLevel = AcademicLevel::get();
            $stageLevel = StageLevel::get();
            $departments = Department::get();
            return view('courses.allcoursescard', compact('courses', 'academicLevel', 'stageLevel', 'departments'));
        } else {
            return view('errors.403');
        }
    }

    /** save data courses */
    public function saveRecord(Request $request)
    { 
        $admin_id = Auth::guard('admin')->user()->id;
        
        $test = $request->validate([
            'name'        => 'required|string|max:255',
            'code'       => 'nullable|unique:courses',
            'academic_level_id' => 'required',
            'stage_level_id'    => 'required',
            'department_id'    => 'required',
            'image'     => 'required',
            'description' =>'required|string' ,
         ]);
        // dd($test);
        $image =$request->file('image');
        $image_name = hexdec(uniqid()).'.'.$image->getClientOriginalExtension();
        $image->move(public_path('upload/Course/'), $image_name);
        $save_url = 'upload/Course/'.$image_name;

        $Course = new Course;
        $Course->name         = $request->name;
        $Course->code        = $request->code;
        $Course->academic_level_id   = $request->academic_level_id;
        $Course->stage_level_id       = $request->stage_level_id;
        $Course->department_id  = $request->department_id;
        $Course->image  = $save_url;
        $Course->description  = $request->description;
        $Course->admin_id  = $admin_id;
        $Course->save();

        Toastr::success('Add new Teahcer successfully :)','Success');
        return redirect()->route('all/courses/card');
             
    }

    /** view edit record */
    public function updateRecord(Request $request)
    {
        //dd($request->all());
        try {
            // $validator = Validator::make($request->all(), [
            //     'name'        => 'required|string|max:255',
            //     'code'       => 'nullable|unique:courses',
            //     'academic_level_id' => 'required',
            //     'stage_level_id'    => 'required',
            //     'department_id'    => 'required',
            //     'image'     => 'required',
            //     'description' =>'required|string' 
            // ]);
    
            // if ($validator->fails()) {
            //     return redirect()->back()->withErrors($validator)->withInput();
            // }
    
            $Course = Course::find($request->id);
    
            if (!$Course) {
                Toastr::error('Course not found not found!', 'Error');
                return redirect()->back();
            }
    
            $old_image = $Course->image;
    
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $image_name = hexdec(uniqid()).'.'.$image->getClientOriginalExtension();
                $image->move(public_path('upload/Course/'), $image_name);
                $save_url = 'upload/Course/'.$image_name;
    
                if ($old_image) {
                    unlink($old_image);
                }
            } else {
                $save_url = $old_image;
            }
    
            $Course->update([
                'name' => $request->name,
                'code' => $request->code,
                'academic_level_id'  => $request->academic_level_id,
                'stage_level_id'       => $request->stage_level_id,
                'department_id'  => $request->department,
                'image' => $save_url,
                'description' => $request->description,
            ]);
    
            Toastr::success('Record updated successfully!', 'Success');
            return redirect()->route('all/courses/card');
        } catch (\Exception $e) {
            Toastr::error('Failed to update record!', 'Error');
            return redirect()->back();
        }
    }

    /** delete record */
    public function deleteRecord(Request $request)
    {
        if (Auth::guard('admin')->user()->can('access any')) {
            // try{
                $Course = Course::find($request->id);
       
                if (!$Course) {
                    Toastr::error('Course not found not found!', 'Error');
                    return redirect()->back();
                }
        
                if ($Course->image) {
                    unlink($Course->image);
                }
                $Course->delete();
                Toastr::success('Delete record successfully :)','Success');
                return redirect()->route('all/courses/card');
            // }catch(\Exception $e){
            //     DB::rollback();
            //     Toastr::error('Delete record fail :)','Error');
            //     return redirect()->back();
            // }
        }else {
                
            return view('errors.403');
        }
    }

    /** courses search */
    public function coursesSearch(Request $request)
    {
        $query = Course::query();

        // Search by course name
        if ($request->name) {
            $query->where('name', 'LIKE', '%' . $request->name . '%');
        }

        // Search by admin name
        if ($request->admin_name) {
            $query->whereHas('teacher', function ($query) use ($request) {
                $query->where('name', 'LIKE', '%' . $request->admin_name . '%');
            });
        }

        // Execute the query and get the results
        $courses = $query->get();
        $courses = $courses->map(function ($course) {
            $course->academicLevel_name = optional($course->academicLevel)->name ?? 'No Academic Level';
            $course->stageLevel_name = optional($course->stageLevel)->name ?? 'No Stage Level';
            $course->department_name = optional($course->department)->name ?? 'No Stage Level';
            return $course; 
        });
        $academicLevel = AcademicLevel::get();
        $stageLevel = StageLevel::get();
        $departments = Department::get();

        // Return the view with the courses data
        return view('courses.allcoursescard', compact('courses','academicLevel','stageLevel','departments'));
    }

    /** Course profile  */
    public function profileCourses($courses_id)
    {
        if (Auth::guard('admin')->user()->can('access any')) {
            $course = Course::findOrFail($courses_id);
            $course->academicLevel_name = optional($course->academicLevel)->name ?? 'No Academic Level';
            $course->stageLevel_name = optional($course->stageLevel)->name ?? 'No Stage Level';
            $course->department_name = optional($course->department)->name ?? 'No Department';
            return view('courses.coursesprofile',compact('course'));
    
        }else {
       
        return view('errors.403');
        }

    
    }

    /** just admin approv coures  */

    public function approv($courses_id)
    {
        if (Auth::guard('admin')->user()->can('access any')) {
            $course = Course::findOrFail($courses_id);

            // Toggle the status between 'active' and 'unactive'
            $newStatus = $course->status === 'active' ? 'unactive' : 'active';

            $course->update([
                'status' => $newStatus,
            ]);

            Toastr::success('Record updated successfully!', 'Success');

            return redirect()->route('all/courses/card');
        } else {
            return view('errors.403');
        }
    }

}
