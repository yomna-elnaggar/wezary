<?php

namespace App\Http\Controllers\Api\userAuth;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Password;
use App\Notifications\ResetPasswordNotification;
use Vonage\Client;
use Vonage\SMS\Message\SMS;
use Vonage\Client\Credentials\Basic;

class ForgotPasswordController extends Controller
{
    public function sendVerificationCode(Request $request)
    {
        $request->validate([
            'phone_number' => 'required|numeric|exists:users,phone_number',
        ]);
    
        $user = User::where('phone_number', $request->input('phone_number'))->first();
    
        // Generate a 6-digit verification code
        $verificationCode = mt_rand(100000, 999999);
    
        // Save the verification code in the user record
        $user->update(['verification_code' => $verificationCode]);
    
        $basic = new Basic("62625aeb", "iJHYFjChz9c4HtFc"); // Vonage API credentials
            $client = new Client($basic);
            $phoneNumber = $user->phone_number; 
            $brandName = "Wzary"; 
            $messageContent = "Your verification code is: " . $verificationCode;
            $response = $client->sms()->send(
                new SMS($phoneNumber, $brandName, $messageContent)
            );

            // Handle SMS sending success or failure
            $message = $response->current();
            if ($message->getStatus() != 0) {
                // SMS sending failed, handle accordingly
                return response()->json(['error' => 'Failed to send verification code'], 500);
            }
            $success['success'] = true;
            $success['name'] = $user->name;
            $success['message'] = 'Verification code sent successfully';
          return response()->json($success, 200);
    }

    public function resetPassword(Request $request)
    {
        // Validate the request
        $request->validate(['new_password' => 'required|min:6|confirmed']);
       
        $user = $request->user();
        // Reset the user's password
        $user->update(['password' => bcrypt($request->input('new_password'))]);

        $success['success'] = true;
        $success['name'] = $user->name;
        $success['token'] = $user->createToken('user', ['app:all'])->plainTextToken;
        $success['message'] = 'Password reset successfully';

        return response()->json($success, 200);
    }

   

}
