<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use App\Models\Course;
use App\Models\Admin;
use App\Models\Department;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function recentlyCourse(Request $request)
    {
        try {
           
            $user = $request->user();
            $recentlyCourse = Course::where('academic_level_id',$user->academic_level_id)
                        ->where('stage_level_id' ,$user->stage_level_id)->latest()->active()->first();

            $success['success'] = true;
            $success['data'] = $recentlyCourse;
            $success['message'] = 'message.success';
            return response()->json($success, 200);
        }catch (\Exception $e) {
            
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }

    public function recentlyCourses(Request $request)
    {
        try {
           
            $user = $request->user();
            $recentlyCourse = Course::where('academic_level_id',$user->academic_level_id)
                        ->where('stage_level_id' ,$user->stage_level_id)->latest()->active()->get();

            $success['success'] = true;
            $success['data'] = $recentlyCourse;
            $success['message'] = 'message.success';
            return response()->json($success, 200);
        }catch (\Exception $e) {
            
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }

    public function departments(Request $request)
    {
        try {
           
            $user = $request->user();
            $department = Department::where('academic_level_id',$user->academic_level_id)
                        ->where('stage_level_id' ,$user->stage_level_id)->latest()->get();

            $success['success'] = true;
            $success['data'] = $department;
            $success['message'] = 'message.success';
            return response()->json($success, 200);
        }catch (\Exception $e) {
            
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }

    public function teachers(Request $request)
    {
        try {
           
            $user = $request->user();
            $teachers = Admin::whereNotIn('id', [1])->get();

            $success['success'] = true;
            $success['data'] = $teachers;
            $success['message'] = 'message.success';
            return response()->json($success, 200);
        }catch (\Exception $e) {
            
            return response()->json(['error' => $e->getMessage()], 500);
        }

    }
    
}
