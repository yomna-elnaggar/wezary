
<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title">
                    <span>Main</span>
                </li>
                <li class="<?php echo e(set_active(['home','em/dashboard'])); ?> submenu">
                    <a href="#" class="<?php echo e(set_active(['home','em/dashboard']) ? 'noti-dot' : ''); ?>">
                        <i class="la la-dashboard"></i>
                        <span> Dashboard</span> <span class="menu-arrow"></span>
                    </a>
                    <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?>">
                           <?php if(Auth::guard('admin')->user()->hasRole('Admin')): ?>
                           <li><a class="<?php echo e(set_active(['home'])); ?>" href="<?php echo e(route('home')); ?>">Admin Dashboard</a></li>
                            <?php elseif(Auth::guard('admin')->user()->hasRole('Teacher')): ?>
                            <li><a class="<?php echo e(set_active(['home'])); ?>" href="">Teacher Dashboard </a></li>
                            <?php endif; ?>
                       
                        
                    </ul>
                </li>
                <?php if(Auth::guard('admin')->user()->can('access any')): ?>
                    <li class="menu-title"> <span>Students</span> </li>
                    <li class="<?php echo e(set_active(['search/user/list','userManagement','activity/log','activity/login/logout'])); ?> submenu">
                        <a href="#" class="<?php echo e(set_active(['search/user/list','userManagement','activity/log','activity/login/logout']) ? 'noti-dot' : ''); ?>">
                            <i class="la la-user-secret"></i> <span> User Controller</span> <span class="menu-arrow"></span>
                        </a>
                        <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?>">
                            <li><a class="<?php echo e(set_active(['search/user/list','userManagement'])); ?>" href="<?php echo e(route('userManagement')); ?>">All User</a></li>
                            <li><a class="<?php echo e(set_active(['activity/log'])); ?>" href="<?php echo e(route('activity/log')); ?>">Activity Log</a></li>
                            <li><a class="<?php echo e(set_active(['activity/login/logout'])); ?>" href="<?php echo e(route('activity/login/logout')); ?>">Activity User</a></li>
                        </ul>
                    </li>
                
                    <li class="menu-title"> <span>Teachers</span> </li>
                    <li class="<?php echo e(set_active(['all/teachers/list','all/teachers/list','all/teachers/card','form/holidays/new','form/leaves/new',
                        'form/leavesemployee/new','form/leavesettings/page','attendance/page',
                        'attendance/employee/page','form/departments/page','form/designations/page',
                        'form/timesheet/page','form/shiftscheduling/page','form/overtime/page'])); ?> submenu">
                        <a href="#" class="<?php echo e(set_active(['all/teachers/list','all/teachers/card','form/holidays/new','form/leaves/new',
                        'form/leavesteachers/new','form/leavesettings/page','attendance/page',
                        'attendance/teachers/page','form/departments/page','form/designations/page',
                        'form/timesheet/page','form/shiftscheduling/page','form/overtime/page']) ? 'noti-dot' : ''); ?>">
                            <i class="la la-user"></i> <span> Teachers</span> <span class="menu-arrow"></span>
                        </a>
                        <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?>">
                            <li><a class="<?php echo e(set_active(['all/teachers/list','all/teachers/card'])); ?> <?php echo e(request()->is('all/teachers/view/edit/*','teachers/profile/*') ? 'active' : ''); ?>" href="<?php echo e(route('all/teachers/card')); ?>">All Teachers</a></li>
                        
                        </ul>
                    </li>

                    <li class="menu-title"> <span>Academic Stages</span> </li>
                    <li class="<?php echo e(set_active(['form/stageLevel/page','form/academicLevel/page',
                        'all/department/list'])); ?> submenu">
                        <a href="#" class="<?php echo e(set_active(['form/academicLevel/page','form/stageLevel/page',
                        'all/department/list']) ? 'noti-dot' : ''); ?>">
                            <i class="la la-hdd"></i> <span> Academic  </span> <span class="menu-arrow"></span>
                        </a>
                        <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?>">
                            
                            <li><a class="<?php echo e(set_active(['form/academicLevel/page'])); ?>" href="<?php echo e(route('form/academicLevel/page')); ?>">Academic Levels</a></li>
                            <li><a class="<?php echo e(set_active(['form/stageLevel/page'])); ?>" href="<?php echo e(route('form/stageLevel/page')); ?>">Stage Levels</a></li>
                            <li><a class="<?php echo e(set_active(['all/department/list'])); ?>" href="<?php echo e(route('all/department/list')); ?>">Department</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                <li class="menu-title"> <span>Courses</span> </li>
                <li class="<?php echo e(set_active(['all/courses/card','form/estimates/page','payments','expenses/page'])); ?> submenu">
                    <a href="#" class="<?php echo e(set_active(['all/courses/card','form/estimates/page','payments','expenses/page']) ? 'noti-dot' : ''); ?>">
                        <i class="la la-files-o"></i>
                        <span> Courses </span> 
                        <span class="menu-arrow"></span>
                    </a>
                    <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?>">
                        <li><a class="<?php echo e(set_active(['all/courses/card'])); ?> }}<?php echo e(request()->is('all/courses/*') ? 'active' : ''); ?>" href="<?php echo e(route('all/courses/card')); ?>">Courses</a></li>
                        
                    </ul>
                </li>
                <li class="menu-title"> <span>Advertisement</span> </li>
                <li class="<?php echo e(set_active(['all/advertisement'])); ?> submenu">
                    <a href="#" class="<?php echo e(set_active(['all/advertisement']) ? 'noti-dot' : ''); ?>"><i class="la la-graduation-cap"></i>
                    <span> Advertisement </span> <span class="menu-arrow"></span></a>
                    <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?>">
                        <li><a class="<?php echo e(set_active(['all/advertisement'])); ?>" href="<?php echo e(route('all/advertisement')); ?>"> Advertisement </a></li>
                    </ul>
                </li>
                <li class="<?php echo e(set_active(['form/training/list/page','form/trainers/list/page'])); ?> submenu"> 
                    <a href="#" class="<?php echo e(set_active(['form/training/list/page','form/trainers/list/page']) ? 'noti-dot' : ''); ?>"><i class="la la-edit"></i>
                    <span> Training </span> <span class="menu-arrow"></span></a>
                    <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?>">
                        <li><a class="<?php echo e(set_active(['form/training/list/page'])); ?>" href="<?php echo e(route('form/training/list/page')); ?>"> Training List </a></li>
                        <li><a class="<?php echo e(set_active(['form/trainers/list/page'])); ?>" href="<?php echo e(route('form/trainers/list/page')); ?>"> Trainers</a></li>
                        <li><a class="<?php echo e(set_active(['form/training/type/list/page'])); ?>" href="<?php echo e(route('form/training/type/list/page')); ?>"> Training Type </a></li>
                    </ul>
                </li>
                <li class="menu-title"> <span>Administration</span> </li>
                <li> <a href="assets.html"><i class="la la-object-ungroup">
                    </i> <span>Assets</span></a>
                </li>
                <li class="<?php echo e(set_active(['user/dashboard/index','jobs/dashboard/index','user/dashboard/all','user/dashboard/applied/jobs','user/dashboard/interviewing','user/dashboard/offered/jobs','user/dashboard/visited/jobs','user/dashboard/archived/jobs','user/dashboard/save','jobs','job/applicants','job/details','page/manage/resumes','page/shortlist/candidates','page/interview/questions','page/offer/approvals','page/experience/level','page/candidates','page/schedule/timing','page/aptitude/result'])); ?> submenu">
                    <a href="#" class="<?php echo e(set_active(['user/dashboard/index','jobs/dashboard/index','user/dashboard/all','user/dashboard/save','jobs','job/applicants','job/details']) ? 'noti-dot' : ''); ?>"><i class="la la-briefcase"></i>
                        <span> Jobs </span> <span class="menu-arrow"></span>
                    </a>
                    <ul style="<?php echo e(request()->is('/*') ? 'display: block;' : 'display: none;'); ?> <?php echo e((request()->is('job/applicants/*')) ? 'display: block;' : 'display: none;'); ?>">
                        <li><a class="<?php echo e(set_active(['user/dashboard/index','user/dashboard/all','user/dashboard/applied/jobs','user/dashboard/interviewing','user/dashboard/offered/jobs','user/dashboard/visited/jobs','user/dashboard/archived/jobs','user/dashboard/save'])); ?>" href="<?php echo e(route('user/dashboard/index')); ?>"> User Dasboard </a></li>
                        <li><a class="<?php echo e(set_active(['jobs/dashboard/index'])); ?>" href="<?php echo e(route('jobs/dashboard/index')); ?>"> Jobs Dasboard </a></li>
                        <li><a class="<?php echo e(set_active(['jobs','job/applicants','job/details'])); ?> <?php echo e((request()->is('job/applicants/*','job/details/*')) ? 'active' : ''); ?>" href="<?php echo e(route('jobs')); ?> "> Manage Jobs </a></li>
                        <li><a class="<?php echo e(set_active(['page/manage/resumes'])); ?>" href="<?php echo e(route('page/manage/resumes')); ?>"> Manage Resumes </a></li>
                        <li><a class="<?php echo e(set_active(['page/shortlist/candidates'])); ?>" href="<?php echo e(route('page/shortlist/candidates')); ?>"> Shortlist Candidates </a></li>
                        <li><a class="<?php echo e(set_active(['page/interview/questions'])); ?>" href="<?php echo e(route('page/interview/questions')); ?>"> Interview Questions </a></li>
                        <li><a class="<?php echo e(set_active(['page/offer/approvals'])); ?>" href="<?php echo e(route('page/offer/approvals')); ?>"> Offer Approvals </a></li>
                        <li><a class="<?php echo e(set_active(['page/experience/level'])); ?>" href="<?php echo e(route('page/experience/level')); ?>"> Experience Level </a></li>
                        <li><a class="<?php echo e(set_active(['page/candidates'])); ?>" href="<?php echo e(route('page/candidates')); ?>"> Candidates List </a></li>
                        <li><a class="<?php echo e(set_active(['page/schedule/timing'])); ?>" href="<?php echo e(route('page/schedule/timing')); ?>"> Schedule timing </a></li>
                        <li><a class="<?php echo e(set_active(['page/aptitude/result'])); ?>" href="<?php echo e(route('page/aptitude/result')); ?>"> Aptitude Results </a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar --><?php /**PATH C:\xampp\htdocs\API\wezary\resources\views/sidebar/sidebar.blade.php ENDPATH**/ ?>