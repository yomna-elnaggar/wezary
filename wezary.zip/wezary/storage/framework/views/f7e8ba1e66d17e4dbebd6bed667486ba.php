<?php $__env->startSection('content'); ?>
   
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <!-- Page Header -->
            <div class="page-header">


                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Stage Level</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Stage Level</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_StageLevel"><i class="fa fa-plus"></i> Add Stage Level</a>
                    </div>
                </div>
            </div>

            <!-- /Page Header -->
            <?php echo Toastr::message(); ?>

            <div class="row">
                <div class="col-md-12">
                    <div>
                        <table class="table table-striped custom-table mb-0 datatable">
                            <thead>
                                <tr>
                                    <th style="width: 30px;">#</th>
                                    <th>Stage Level Name</th>
                                    <th>Academic Level Name</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $stageLevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td hidden class="id"><?php echo e($items->id); ?></td>
                                    <td class="StageLevel"><?php echo e($items->name); ?></td>
                                    <td  class="academicLevel" data-id="<?php echo e($items->academicLevel->id); ?>"><?php echo e($items->academicLevel->name); ?></td>
                                    <td class="text-right">
                                    <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item  edit_StageLevel" href="#" data-toggle="modal" data-target="#edit_StageLevel"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                            <a class="dropdown-item delete_edit_StageLevel" href="#" data-toggle="modal" data-target="#delete_StageLevel"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                        </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Content -->
        
        <!-- Add StageLevel Modal -->
        <div id="add_StageLevel" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Stage Level</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Display validation errors here -->
                        <div id="errorContainer"></div>
                        <form action="<?php echo e(route('form/stageLevel/save')); ?>" method="POST" id="addStageForm">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Stage Level Name <span class="text-danger">*</span></label>
                                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="name" name="name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label>Academic Level <span class="text-danger">*</span></label>
                                <select class="select form-control"   id="academic_level_id" name="academic_level_id">
                                    <option value="">-- Select --</option>
                                    <?php $__currentLoopData = $academicLevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" ><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="submit-section">
                                <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Add StageLevel Modal -->
        
        <!-- Edit StageLevel Modal -->
        <div id="edit_StageLevel" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Stage Level</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('form/stageLevel/update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" id="e_id" value="">
                            <div class="form-group">
                                <label>Stage Level Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="StageLevel_edit" name="name" value="">
                            </div>
                            <div class="form-group">
                                <label>Academic Level <span class="text-danger">*</span></label>
                                <select class="select form-control" id="academic_level_id" name="academic_level_id">
                                    <option value="" selected>-- Select --</option>
                                    <?php $__currentLoopData = $academicLevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="submit-section">
                                <button type="submit" class="btn btn-primary submit-btn">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Edit StageLevel Modal -->

        <!-- Delete StageLevel Modal -->
        <div class="modal custom-modal fade" id="delete_StageLevel" role="dialog">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="form-header">
                            <h3>Delete Stage Level</h3>
                            <p>Are you sure want to delete?</p>
                        </div>
                        <div class="modal-btn delete-action">
                            <form action="<?php echo e(route('form/stageLevel/delete')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" class="e_id" value="">
                                <div class="row">
                                    <div class="col-6">
                                        <button type="submit" class="btn btn-primary continue-btn submit-btn">Delete</button>
                                    </div>
                                    <div class="col-6">
                                        <a href="javascript:void(0);" data-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Delete StageLevel Modal -->
    </div>

    <!-- /Page Wrapper -->
    <?php $__env->startSection('script'); ?>
    
    <script>
        $(document).on('click', '.edit_StageLevel', function() {
            var _this = $(this).closest('tr');
            var id = _this.find('.id').text();
            var name = _this.find('.StageLevel').text();
            var academicLevelId = _this.find('.academicLevel').data('id');
            var academicLevelName = _this.find('.academicLevel').text();
    
            $('#e_id').val(id);
            $('#StageLevel_edit').val(name);
            
            // Set the selected academic level ID in the select dropdown
            $('#academic_level_id').val(academicLevelId);
            
            // Set the selected academic level name as the text of the selected option in the select dropdown
            $('#academic_level_id option:selected').text(academicLevelName);
        });
    </script>
    
    <script>
        $(document).on('click','.delete_StageLevel',function()
        {
            var _this = $(this).parents('tr');
            $('.e_id').val(_this.find('.id').text());
        });
    </script>

<script>
    $(document).ready(function() {
        $('#addStageForm').submit(function(e) {
            e.preventDefault();
            var form = $(this);
            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: new FormData(this),
                processData: false,
                contentType: false,
                success: function(response) {
                    // If form submission is successful, do something (e.g., show a success message)
                    toastr.success('Stage Level added successfully!');
                    // Close the modal after 2 seconds (adjust the time as needed)
                    $('#add_StageLevel').modal('hide');
                    // Reload the page after successful submission
                    window.location.reload();
                },
                error: function(xhr) {
                    // If form submission fails due to validation errors, display errors dynamically
                    var errors = xhr.responseJSON.errors;
                    var errorList = '';
                    $.each(errors, function(key, value) {
                        errorList += '<li>' + value + '</li>';
                    });
                    $('#errorContainer').html('<div class="alert alert-danger">' +
                        '<ul>' + errorList + '</ul>' +
                        '</div>').show();
                }
            });
        });
    });
</script>


    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\API\wezary\resources\views/educational/stageLevel.blade.php ENDPATH**/ ?>